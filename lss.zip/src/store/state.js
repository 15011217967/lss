const state = {
  name: '张三',
  age: 18,
  actionsName:'',
  barList:[]
}

export default state;
