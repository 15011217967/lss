<template>
  <div class="home">
    argu
    {{ $route.params.name }}
  </div>
</template>

<script>
// @ is an alias to /src
export default{
  data () {
    return {
      
    }
  },
  created() {
  }
}
</script>
